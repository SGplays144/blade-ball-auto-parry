# blade-ball-auto-parry
Blade Ball Auto Parry (Python)
🎯 An automatic parry system for Blade Ball — written in Python!

✨ Features
Automatically detects when a ball gets close

Instantly performs a parry action

Super fast reaction time — faster than any human!

Lightweight and efficient — no need to install Python to run it

Delivered as a ready-to-use .exe file

🚀 How It Works
The script continuously monitors the distance between your character and incoming balls.
When a ball gets within a certain range, it instantly triggers a parry action!

The project was originally written in Python.

![blade-ball-script-auto-parry](https://github.com/user-attachments/assets/25a331f9-2070-46c8-83ac-01bc431145fc)


# Important
This script is not signed with a trusted certificate, so you will receive a warning. To avoid this, right-click on launcher.bat, select Properties, check Unblock at the bottom if available, click Apply, and then click ok

# Virus checker
If you dont trust this file you can test it by your self with these malware testers there should only show python detected.
https://internxt.com/virus-scanner
https://virusscan.jotti.org/
